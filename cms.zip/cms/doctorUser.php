<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.png" type="image/png">
<title>Doctor | MY GOV Hospitals</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/coda-slider.css" type="text/css" media="screen"/>
<script src="js/jquery-1.2.6.js" type="text/javascript"></script>
<script src="js/coda-slider.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript" charset="utf-8"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>

</head>
<body>

<div id="slider">
	
    <div id="templatemo_sidebar">
    	<div id="templatemo_header">
        	<img src="images/logo.png" alt="MYGovHospital" width="230" height="80" style="position:absolute;top:80px;left:80px;"/>

        </div> <!-- end of header -->
        
        <ul class="navigation">
            <li><a href="doctorUser.php">Home<span class="ui_icon home"></span></a></li>
			<li><a href="diagnosis.php">Diagnosis<span class="ui_icon diagnosis"></span></a></li>
               
        </ul>
    </div> <!-- end of sidebar -->
	<div id="templatemo_main">
    	<ul id="social_box">
            <li><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a></li>
            <li><a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a></li>
            <li><a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="linkin" /></a></li>
            <li><a href="https://portal.technoratimedia.com/" target="_blank"><img src="images/technorati.png" alt="technorati" /></a></li>
            <li><a href="https://myspace.com/" target="_blank"><img src="images/myspace.png" alt="myspace" /></a></li>                
        </ul>
		<div id="loginSignup">
			<a href="loginSignup.php">
			<img src="images/logoutBtn.png" alt="Login/SignUp" width="180" height="48" class="image"
			onmouseover="this.src='images/logoutBtn_hover.png'"
			onmouseout="this.src='images/logoutBtn.png'"></a>
		</div>
		<!--end of loginSignup-->
		<div id="content">
			<h1>Appointment</h1>
			<table cellspacing=0 cellpadding=5>
			<tr><td>No</td><td>Date</td><td>Time</td><td>Patient</td><td></td></tr>
				<?php
				session_start();
				$doctorID=$_SESSION['doctorID'];
				$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "mygovhospital";
				$con = new mysqli($servername, $username, $password, $dbname);
				$sql1 = "SELECT * FROM appointment WHERE doctorID='".$doctorID."'";
				$result = mysqli_query($con, $sql1);
				$list = array();
				while($row = $result->fetch_assoc())
				{
					$list[] = $row;
				}
				$value = array();
				foreach($list as $key=>$val)
				{
					foreach($val as $k=>$v)
					{ 
					// $v is string.
					// And $k is $val array index (0, 1, ....)
					$value[] = $v;		
					}
				}
				$appointments = array();
				$counter =0;
				$length = count($value);
				for($i=0;$i<$length;$i++)
				{
					$appointment[] = $value[$i];
					$counter++;
					if($counter==5)
					{
						$appointments[] = $appointment;
						$appointment = array();
						$counter = 0;
					}
				}
				$totalAppointment = count($appointments);
				for($i=0;$i<$totalAppointment;$i++)
				{
					$appointment = $appointments[$i];
					$date = $appointment[1];
					$timeslot = $appointment[2];
					$patientID = $appointment[3];
					$sql1 = "SELECT * FROM patient WHERE patientID = '".$patientID."'";
					$result = mysqli_query($con, $sql1);
					$row = mysqli_fetch_assoc($result);
					$patientName=$row['name'];
					echo '<tr><td>'.($i+1).'</td><td>'.$date.'</td><td>'.$timeslot.'</td><td>'.$patientName.'</td>
					<td><a href=appointmentmod.php?rno="'.$appointment[0].'">Modify</a></td></tr>';
				}
				?>
			</table>
        </div> <!-- end of content -->
		<div id="templatemo_footer">
			Copyright © 2017 <a href="doctorUser.php">MYGovHospital</a> | <a href="#content" target="_parent">Doctor | MY Gov Hospital</a> by <a href="doctorUser.php" target="_parent">MY GOV Hospital</a>
        </div> <!-- end of footer -->
    </div> <!-- end of main -->
</div>
</body>
</html>