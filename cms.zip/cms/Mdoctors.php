<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.png" type="image/png">
<title>Admin | MY GOV Hospitals</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/coda-slider.css" type="text/css" media="screen"/>
<script src="js/jquery-1.2.6.js" type="text/javascript"></script>
<script src="js/coda-slider.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript" charset="utf-8"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>

</head>
<body>

<div id="slider">
	
    <div id="templatemo_sidebar">
    	<div id="templatemo_header">
        	<img src="images/logo.png" alt="MYGovHospital" width="230" height="80" style="position:absolute;top:80px;left:80px;"/>

        </div> <!-- end of header -->
        
        <ul class="navigation">
            <li><a href="admin.php">Home<span class="ui_icon home"></span></a></li>
               
        </ul>
    </div> <!-- end of sidebar -->
	<div id="templatemo_main">
    	<ul id="social_box">
            <li><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a></li>
            <li><a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a></li>
            <li><a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="linkin" /></a></li>
            <li><a href="https://portal.technoratimedia.com/" target="_blank"><img src="images/technorati.png" alt="technorati" /></a></li>
            <li><a href="https://myspace.com/" target="_blank"><img src="images/myspace.png" alt="myspace" /></a></li>                
        </ul>
		<div id="loginSignup">
			<a href="loginSignup.php">
			<img src="images/logoutBtn.png" alt="Login/SignUp" width="180" height="48" class="image"
			onmouseover="this.src='images/logoutBtn_hover.png'"
			onmouseout="this.src='images/logoutBtn.png'"></a>
		</div>
		<!--end of loginSignup-->
		<div id="content">
			<h1>Maintain Website Information</h1>
			<table cellspacing=0 cellpadding=5>
			<tr><li><a href=admin.php>Hospitals</a></li><li><a href=Mdoctors.php>Doctors</a></li><li><a href=Machv.php>Achievements</a></li></td></tr>
			<tr><td ><h3>Doctors List</h3></td></tr>
			<tr><td><a href=dadd.php>Add New Record</a></td></tr>
			<tr><td><table cellspacing=0 cellpadding=5>
			<tr><td>No</td><td>Doctor Name</td><td>Specialization</td><td></td><td></td></tr>
			<?php
			$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "mygovhospital";
				$con = new mysqli($servername, $username, $password, $dbname);
				$sql1 = "SELECT * FROM doctor WHERE dshow='Y'";
				$result = mysqli_query($con, $sql1);
				$list = array();
				while($row = $result->fetch_assoc())
				{
					$list[] = $row;
				}
				mysqli_close($con);
				$value = array();
				foreach($list as $key=>$val)
				{
					foreach($val as $k=>$v)
					{ 
					// $v is string.
					// And $k is $val array index (0, 1, ....)
					$value[] = $v;		
					}
				}
				$doctors = array();
				$counter =0;
				$length = count($value);
				for($i=0;$i<$length;$i++)
				{
					$doctor[] = $value[$i];
					$counter++;
					if($counter==6)
					{
						$doctors[] = $doctor;
						$doctor = array();
						$counter = 0;
					}
				}
				$doctorNum = count($doctors);
				for($i=0;$i<$doctorNum;$i++)
				{
					$doctor = $doctors[$i];
					$doctorName = $doctor[1];
					$specialization = $doctor[2];
					echo '<tr><td>'.($i+1).'</td><td>'.$doctorName.'</td><td>'.$specialization.'</td>
					<td><a href=dmod.php?rno="'.$doctor[0].'">Modify</a></td>
					<td><a href=ddel.php?rno="'.$doctor[0].'">Delete</a></td></tr>';
				}
			?>
			</table></td></tr>
			<tr><td align=center><hr></td></tr>
			<tr><td><h3>Deleted Records</h3></td></tr>
			<tr><td><table cellspacing=0 cellpadding=5>
			<?php
			$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "mygovhospital";
				$con = new mysqli($servername, $username, $password, $dbname);
				$sql1 = "SELECT * FROM doctor WHERE dshow='N'";
				$result = mysqli_query($con, $sql1);
				$list = array();
				while($row = $result->fetch_assoc())
				{
					$list[] = $row;
				}
				mysqli_close($con);
				$value = array();
				foreach($list as $key=>$val)
				{
					foreach($val as $k=>$v)
					{ 
					// $v is string.
					// And $k is $val array index (0, 1, ....)
					$value[] = $v;		
					}
				}
				$doctors = array();
				$doctor = array();
				$counter =0;
				$length = count($value);
				for($i=0;$i<$length;$i++)
				{
					$doctor[] = $value[$i];
					$counter++;
					if($counter==6)
					{
						$doctors[] = $doctor;
						$doctor = array();
						$counter = 0;
					}
				}
				$doctorNum = count($doctors);
				if($doctorNum==0)
					echo '<p>No Records</p>';
				else
				{
					echo '<tr><td>No</td><td>Name</td><td>Specialization</td><td></td></tr>';
					for($i=0;$i<$doctorNum;$i++)
					{
						$doctor = $doctors[$i];
						$name = $doctor[1];
						$specialization = $doctor[2];
						echo '<tr><td>'.($i+1).'</td><td>'.$name.'</td><td>'.$specialization.'</td>
						<td><a href=dundel.php?rno="'.$doctor[0].'">Undelete</a></td></tr>';
					}
				}
			?>
			</table></td></tr>
			</table>

		<a href="#content">Back to Top</a>
        </div> <!-- end of content -->
		<div id="templatemo_footer">
			Copyright © 2017 <a href="admin.php">MYGovHospital</a> | <a href="#content" target="_parent">Admin | MY Gov Hospital</a> by <a href="admin.php" target="_parent">MY GOV Hospital</a>
        </div> <!-- end of footer -->
    </div> <!-- end of main -->
</div>
</body>
</html>