<?php
					session_start();
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "mygovhospital";
					$con = new mysqli($servername, $username, $password, $dbname);
					$timeslot=$_POST['timeslot'];
					$appointmentID=$_SESSION['appointmentID'];
					$date=$_SESSION['date'];
					$sql1 = "UPDATE appointment SET date='".$date."',timeslot='".$timeslot."' WHERE appointmentID=".$appointmentID."";
					if (mysqli_query($con, $sql1))
						{
							echo '<script type="text/javascript">',
							 'message();',
							 '</script>'
							;
							header('location:doctorUser.php');						
						}
					else
					{
						echo "Error.";
					}
				
?>
<script>
function message()
{
	alert('Appointment updated.');
	
}
</script>