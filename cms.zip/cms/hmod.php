<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.png" type="image/png">
<title>Admin | MY GOV Hospitals</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/coda-slider.css" type="text/css" media="screen"/>
<script src="js/jquery-1.2.6.js" type="text/javascript"></script>
<script src="js/coda-slider.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript" charset="utf-8"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>

</head>
<body>

<div id="slider">
	
    <div id="templatemo_sidebar">
    	<div id="templatemo_header">
        	<img src="images/logo.png" alt="MYGovHospital" width="230" height="80" style="position:absolute;top:80px;left:80px;"/>

        </div> <!-- end of header -->
        
        <ul class="navigation">
            <li><a href="admin.php">Home<span class="ui_icon home"></span></a></li>
               
        </ul>
    </div> <!-- end of sidebar -->
	<div id="templatemo_main">
    	<ul id="social_box">
            <li><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a></li>
            <li><a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a></li>
            <li><a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="linkin" /></a></li>
            <li><a href="https://portal.technoratimedia.com/" target="_blank"><img src="images/technorati.png" alt="technorati" /></a></li>
            <li><a href="https://myspace.com/" target="_blank"><img src="images/myspace.png" alt="myspace" /></a></li>                
        </ul>
		<div id="loginSignup">
			<a href="loginSignup.php">
			<img src="images/logoutBtn.png" alt="Login/SignUp" width="180" height="48" class="image"
			onmouseover="this.src='images/logoutBtn_hover.png'"
			onmouseout="this.src='images/logoutBtn.png'"></a>
		</div>
		<!--end of loginSignup-->
		<div id="content">
			<h1>Maintain Website Information</h1>
			<table cellspacing=0 cellpadding=5>
			<tr><li><a href=admin.php>Hospitals</a></li><li><a href=Mdoctors.php>Doctors</a></li><li><a href=Machv.php>Achievements</a></li></td></tr>
			<tr><td><h3>Modify Hospital</h3></td></tr></table>
                    <?php
					session_start();
					$hospitalID=trim($_GET["rno"]);
					$_SESSION['hospitalID']=$hospitalID;
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "mygovhospital";
					$con = new mysqli($servername, $username, $password, $dbname);
					$sql1 = "SELECT * FROM hospital WHERE hospitalID=".$hospitalID."";
					$result = mysqli_query($con, $sql1);
					$row = mysqli_fetch_assoc($result);
					echo'

					<div id="contact_form">
					<form action="hsave.php" method="post" >					
                    <label for="name">Hospital Name:</label> <input type="text" id="name" name="name" value="'.$row['name'].'" class="required input_field" required />
                    <div class="cleaner_h10"></div>
                                
                    <label for="address">Address:</label> <input type="text" id="address" name="address" value="'.$row['address'].'" class="required input_field" required />
                    <div class="cleaner_h10"></div> 
					
                    <label for="phoneNum">Phone Num:</label> <input type="text" id="phoneNum" name="phoneNum"  value="'.$row['phoneNum'].'" class="required input_field" required />
                    <div class="cleaner_h10"></div>
                                
                    <label for="longitude">Longitude:</label> <input type="text" id="longitude" name="longitude"  value="'.$row['longitude'].'" class="required input_field" required />
                    <div class="cleaner_h10"></div>   
					
                    <label for="latitude">Latitude:</label> <input type="text" id="latitude" name="latitude" value="'.$row['latitude'].'"  class="required input_field" required />
                    <div class="cleaner_h10"></div>
                                
                    <input type="submit" class="submit_btn" name="update" id="update" value="Update" />
                    <input type="reset" class="submit_btn" name="cancel" id="cancel" value="Cancel" onclick="goPreviousPage()"/>
					</form>
					</div>';
                     ?>       

        </div> <!-- end of content -->
		<div id="templatemo_footer">
			Copyright © 2017 <a href="admin.php">MYGovHospital</a> | <a href="#content" target="_parent">Admin | MY Gov Hospital</a> by <a href="admin.php" target="_parent">MY GOV Hospital</a>
        </div> <!-- end of footer -->
    </div> <!-- end of main -->
</div>
</body>
<script type="text/javascript">
		
		function goPreviousPage() 
		{
			window.history.back();
		}
</script>
</html>