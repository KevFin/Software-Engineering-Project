<table cellspacing=0 cellpadding=5>
<tr><td>No</td><td>Date</td><td>Time</td><td>Patient</td><td></td></tr>
	<?php
	session_start();
	$doctorID=$_SESSION['doctorID'];
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "mygovhospital";
	$con = new mysqli($servername, $username, $password, $dbname);
	$sql1 = "SELECT * FROM appointment WHERE doctorID='".$doctorID."'";
	$result = mysqli_query($con, $sql1);
	$list = array();
	while($row = $result->fetch_assoc())
	{
		$list[] = $row;
	}
	$value = array();
	foreach($list as $key=>$val)
	{
		foreach($val as $k=>$v)
		{ 
		// $v is string.
		// And $k is $val array index (0, 1, ....)
		$value[] = $v;		
		}
	}
	$appointments = array();
	$counter =0;
	$length = count($value);
	for($i=0;$i<$length;$i++)
	{
		$appointment[] = $value[$i];
		$counter++;
		if($counter==5)
		{
			$appointments[] = $appointment;
			$appointment = array();
			$counter = 0;
		}
	}
	$totalAppointment = count($appointments);
	for($i=0;$i<$totalAppointment;$i++)
	{
		$appointment = $appointments[$i];
		$date = $appointment[1];
		$timeslot = $appointment[2];
		$patientID = $appointment[3];
		$sql1 = "SELECT * FROM patient WHERE patientID = '".$patientID."'";
		$result = mysqli_query($con, $sql1);
		$row = mysqli_fetch_assoc($result);
		$patientName=$row['name'];
		echo '<tr><td>'.($i+1).'</td><td>'.$date.'</td><td>'.$timeslot.'</td><td>'.$patientName.'</td>
		<td><a href=appointmentmod.php?rno="'.$appointment[0].'">Modify</a></td></tr>';
	}
	?>
</table>