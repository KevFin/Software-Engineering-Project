<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.png" type="image/png">
<title>Patient | MY GOV Hospitals</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/coda-slider.css" type="text/css" media="screen"/>
<script src="js/jquery-1.2.6.js" type="text/javascript"></script>
<script src="js/coda-slider.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript" charset="utf-8"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  <script>
  $(document).ready(function() {
    $("#datepicker").datepicker({
    dateFormat: 'yy-mm-dd',
    minDate: 0, // 0 days offset = today
    maxDate: '+4m -1w',
    onSelect: function(dateText) {
        $sD = new Date(dateText);
        $("input#DateTo").datepicker('option', 'minDate', min);
    }
});
  });
  </script>
</head>
<body>

<div id="slider">
	
    <div id="templatemo_sidebar">
    	<div id="templatemo_header">
        	<img src="images/logo.png" alt="MYGovHospital" width="230" height="80" style="position:absolute;top:80px;left:80px;"/>

        </div> <!-- end of header -->
        
        <ul class="navigation">
            <li><a href="patientUser.php">Appointment<span class="ui_icon appointment"></span></a></li>
			<li><a href="purchaseMed.php">Medicine<span class="ui_icon medicine"></span></a></li>
               
        </ul>
    </div> <!-- end of sidebar -->
	<div id="templatemo_main">
    	<ul id="social_box">
            <li><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a></li>
            <li><a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a></li>
            <li><a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="linkin" /></a></li>
            <li><a href="https://portal.technoratimedia.com/" target="_blank"><img src="images/technorati.png" alt="technorati" /></a></li>
            <li><a href="https://myspace.com/" target="_blank"><img src="images/myspace.png" alt="myspace" /></a></li>                
        </ul>
		<div id="loginSignup">
			<a href="loginSignup.php">
			<img src="images/logoutBtn.png" alt="Login/SignUp" width="180" height="48" class="image"
			onmouseover="this.src='images/logoutBtn_hover.png'"
			onmouseout="this.src='images/logoutBtn.png'"></a>
		</div>
		<!--end of loginSignup-->
		<div id="content">
			<h1>Create Appointment</h1>
			<?php
				session_start();
				$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "mygovhospital";
				$con = new mysqli($servername, $username, $password, $dbname);
				$patientID=$_SESSION['patientID'];
				$doctorID=$_SESSION['selectedDoctorID'];
				$date=$_SESSION['date'];
				$timeslot=$_POST['timeslot'];
				$sql1 = "INSERT INTO appointment (date, timeslot, patientID, doctorID) 
															VALUES ('".$date."','".$timeslot."','".$patientID."','".$doctorID."')";
				if (mysqli_query($con, $sql1))
				{
					echo 'Apppointment Created.'	;
				}
				else
					echo "Error.";
				echo '<div class="cleaner_h10"></div>';
				echo '<a href=\'patientUser.php\'><img src="images/backBtn.png" alt="Back" width="71" height="30" class="image"
			onmouseover="this.src=\'images/backBtn_hover.png\'"
			onmouseout="this.src=\'images/backBtn.png\'"></a>';
			?>
        </div> <!-- end of content -->
		<div id="templatemo_footer">
			Copyright © 2017 <a href="patientUser.php">MYGovHospital</a> | <a href="#content" target="_parent">Patient | MY Gov Hospital</a> by <a href="patientUser.php" target="_parent">MY GOV Hospital</a>
        </div> <!-- end of footer -->
    </div> <!-- end of main -->
</div>
</body>

</html>