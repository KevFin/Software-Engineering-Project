 <?php
	$doctorID=trim($_GET["rno"]);
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "mygovhospital";
	$con = new mysqli($servername, $username, $password, $dbname);
	$sql1 = "UPDATE doctor SET dshow='Y' WHERE doctorID=".$doctorID."";
	if (mysqli_query($con, $sql1))
	{
		header('location:Mdoctors.php');						
	}
	else
	{
		echo "<script>alert('Error in deleting');</script>"; 
	}
	//"delete" achievements of the deleted doctor
	$sql2 = "UPDATE achievement SET ashow='Y' WHERE doctorID=".$doctorID."";
	mysqli_query($con, $sql2);
?>