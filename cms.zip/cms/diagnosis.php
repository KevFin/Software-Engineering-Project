<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.png" type="image/png">
<title>Doctor | MY GOV Hospitals</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/coda-slider.css" type="text/css" media="screen"/>
<script src="js/jquery-1.2.6.js" type="text/javascript"></script>
<script src="js/coda-slider.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript" charset="utf-8"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>

</head>
<body>

<div id="slider">
	
    <div id="templatemo_sidebar">
    	<div id="templatemo_header">
        	<img src="images/logo.png" alt="MYGovHospital" width="230" height="80" style="position:absolute;top:80px;left:80px;"/>

        </div> <!-- end of header -->
        
        <ul class="navigation">
            <li><a href="doctorUser.php">Home<span class="ui_icon home"></span></a></li>
			<li><a href="diagnosis.php">Diagnosis<span class="ui_icon diagnosis"></span></a></li>
               
        </ul>
    </div> <!-- end of sidebar -->
	<div id="templatemo_main">
    	<ul id="social_box">
            <li><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a></li>
            <li><a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a></li>
            <li><a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="linkin" /></a></li>
            <li><a href="https://portal.technoratimedia.com/" target="_blank"><img src="images/technorati.png" alt="technorati" /></a></li>
            <li><a href="https://myspace.com/" target="_blank"><img src="images/myspace.png" alt="myspace" /></a></li>                
        </ul>
		<div id="loginSignup">
			<a href="loginSignup.php">
			<img src="images/logoutBtn.png" alt="Login/SignUp" width="180" height="48" class="image"
			onmouseover="this.src='images/logoutBtn_hover.png'"
			onmouseout="this.src='images/logoutBtn.png'"></a>
		</div>
		<!--end of loginSignup-->
		<div id="content">
			<h1>Create Diagnosis and Prescription</h1>
			<div id="contact_form">
			<form id="diagnosis" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
				<?php
				session_start();
				$doctorID=$_SESSION['doctorID'];
				$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "mygovhospital";
				$con = new mysqli($servername, $username, $password, $dbname);
				$sql1 = "SELECT * FROM patient ";
				$result = mysqli_query($con, $sql1);
				$list = array();
				while($row = $result->fetch_assoc())
				{
					$list[] = $row;
				}
				$value = array();
				foreach($list as $key=>$val)
				{
					foreach($val as $k=>$v)
					{ 
					// $v is string.
					// And $k is $val array index (0, 1, ....)
					$value[] = $v;		
					}
				}
				$patients = array();
				$patient = array();
				$counter =0;
				$length = count($value);
				for($i=0;$i<$length;$i++)
				{
					$patient[] = $value[$i];
					$counter++;
					if($counter==5)
					{
						$patients[] = $patient;
						$patient = array();
						$counter = 0;
					}
				}
				$totalPatient = count($patients);
				$remark="";
				$spinnerValue=1;
				$numOfMed=0;
				if(isset($_POST['getMedicine']))//check if user pressed 'check'
				{
					$selectedPatientID=$_POST['patientID'];
					$remark=$_POST['remark'];
					$numOfMed=$_POST['totalMedPres_spinner'];
					$_SESSION['diagnosisPatientID']=$selectedPatientID;
					$_SESSION['remark']=$remark;
					$_SESSION['numofmed']=$numOfMed;
					$spinnerValue=$numOfMed;
				}
				echo '<label for="patientID">Patient:</label>';
				echo '<select name="patientID" class="input_field">';
				for($i=0;$i<$totalPatient;$i++)
				{	
					$patient = $patients[$i];
					$patientID=$patient[0];
					$patientName=$patient[1];
					if($patientID==$selectedPatientID)
					{
						$selected = "selected";
					}
					else
						$selected="";
					echo '<option value='.$patient[0].' '.$selected.'>'.$patient[1].'</option>';					
				}
				echo '</select>';
				echo '<div class="cleaner_h10"></div>';
				echo '<label for="remark">Remark:</label> <textarea id="remark" name="remark" class="required input_field" required rows="4" cols="50" >'.$remark.'</textarea>';
				echo '<div class="cleaner_h10"></div>';
				echo '<label for="totalMedPres" style="width: 200px">Number of medicine:</label>';
				echo '<input id="totalMedPres_spinner" name="totalMedPres_spinner" type="number" min="1" max="10" value="'.$spinnerValue.'" style="width: 30px; background: #333028; border: 1px solid #886; color: #FFF;"/>';
				echo '<div class="cleaner_h10"></div>';
				echo'<input type="submit" class="submit_btn" name="getMedicine" id="getMedicine" value="Create Prescription" />';
				echo '</form>';					
				echo '</div>';
				// display medicine
				$sql2 = "SELECT * FROM medicine ";
				$result = mysqli_query($con, $sql2);
				$list = array();
				while($row = $result->fetch_assoc())
				{
					$list[] = $row;
				}
				$value = array();
				foreach($list as $key=>$val)
				{
					foreach($val as $k=>$v)
					{ 
					// $v is string.
					// And $k is $val array index (0, 1, ....)
					$value[] = $v;		
					}
				}
				$medicines = array();
				$medicine = array();
				$counter =0;
				$length = count($value);
				for($i=0;$i<$length;$i++)
				{
					$medicine[] = $value[$i];
					$counter++;
					if($counter==3)
					{
						$medicines[] = $medicine;
						$medicine = array();
						$counter = 0;
					}
				}
				$totalMedicine = count($medicines);
				echo '<div id="contact_form">';
				echo '<form id="diagnosis" method="POST" action="createDiagnosis.php">';
				if(isset($_POST['getMedicine']))
				{
				echo '<label for="medicineID">Medicine:</label>';
				for($num=0;$num<$numOfMed;$num++)
				{
					echo '<select name="medicineID['.$num.']" class="input_field" style="width: 200px;">';
					for($i=0;$i<$totalMedicine;$i++)
					{	
						$medicine = $medicines[$i];
						echo '<option value='.$medicine[0].' >'.$medicine[1].'</option>';					
					}
					echo '</select> ';
					echo '<input type="text" id="amount['.$num.']" name="amount['.$num.']" class="required input_field" required  style="width: 50px;" placeholder="amount"/>';
					echo '<div class="cleaner_h10"></div>';
				}
				echo'<input type="submit" class="submit_btn" name="submit" id="submit" value="Create" />
						<input type="reset" class="submit_btn" name="reset" id="reset" value="Reset" />';
				}
				echo '</form>';					
				echo '</div>';						
				?>
        </div> <!-- end of content -->
		<div id="templatemo_footer">
			Copyright © 2017 <a href="doctorUser.php">MYGovHospital</a> | <a href="#content" target="_parent">Doctor | MY Gov Hospital</a> by <a href="doctorUser.php" target="_parent">MY GOV Hospital</a>
        </div> <!-- end of footer -->
    </div> <!-- end of main -->
</div>
</body>
</html>