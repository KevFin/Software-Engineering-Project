<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.png" type="image/png">
<title>Patient | MY GOV Hospitals</title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/coda-slider.css" type="text/css" media="screen"/>
<script src="js/jquery-1.2.6.js" type="text/javascript"></script>
<script src="js/coda-slider.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript" charset="utf-8"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script> 
  <script>
  $(document).ready(function() {
    $("#datepicker").datepicker({
    dateFormat: 'yy-mm-dd',
    minDate: 0, // 0 days offset = today
    maxDate: '+4m -1w',
    onSelect: function(dateText) {
        $sD = new Date(dateText);
        $("input#DateTo").datepicker('option', 'minDate', min);
    }
});
  });
  </script>
</head>
<body>

<div id="slider">
	
    <div id="templatemo_sidebar">
    	<div id="templatemo_header">
        	<img src="images/logo.png" alt="MYGovHospital" width="230" height="80" style="position:absolute;top:80px;left:80px;"/>

        </div> <!-- end of header -->
        
        <ul class="navigation">
            <li><a href="patientUser.php">Appointment<span class="ui_icon appointment"></span></a></li>
			<li><a href="purchaseMed.php">Medicine<span class="ui_icon medicine"></span></a></li>
               
        </ul>
    </div> <!-- end of sidebar -->
	<div id="templatemo_main">
    	<ul id="social_box">
            <li><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.png" alt="facebook" /></a></li>
            <li><a href="https://twitter.com/" target="_blank"><img src="images/twitter.png" alt="twitter" /></a></li>
            <li><a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="linkin" /></a></li>
            <li><a href="https://portal.technoratimedia.com/" target="_blank"><img src="images/technorati.png" alt="technorati" /></a></li>
            <li><a href="https://myspace.com/" target="_blank"><img src="images/myspace.png" alt="myspace" /></a></li>                
        </ul>
		<div id="loginSignup">
			<a href="loginSignup.php">
			<img src="images/logoutBtn.png" alt="Login/SignUp" width="180" height="48" class="image"
			onmouseover="this.src='images/logoutBtn_hover.png'"
			onmouseout="this.src='images/logoutBtn.png'"></a>
		</div>
		<!--end of loginSignup-->
		<div id="content">
			<h1>Create Appointment</h1>
			<div id="contact_form">
			<form id="checkAvailabilityForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">				
			<?php
			$date="";
			$selectedDoctorID="";
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "mygovhospital";
			$con = new mysqli($servername, $username, $password, $dbname);
			$sql1 = "SELECT * FROM doctor WHERE dshow='Y'";
			$result = mysqli_query($con, $sql1);
			$list = array();
			while($row = $result->fetch_assoc())
			{
				$list[] = $row;
			}
			mysqli_close($con);
			$value = array();
			foreach($list as $key=>$val)
			{
				foreach($val as $k=>$v)
				{ 
				// $v is string.
				// And $k is $val array index (0, 1, ....)
				$value[] = $v;		
				}
			}
			$doctors = array();
			$counter =0;
			$length = count($value);
			for($i=0;$i<$length;$i++)
			{
				$doctor[] = $value[$i];
				$counter++;
				if($counter==6)
				{
					$doctors[] = $doctor;
					$doctor = array();
					$counter = 0;
				}
			}
			$doctorNum = count($doctors);
			if(isset($_POST['checkAvailability']))//check if user pressed 'check'
			{
				$selectedDoctorID=$_POST['doctorID'];
				$date=$_POST['date'];
			}
			echo '<label for="doctorID">Doctor:</label>';
			echo '<select name="doctorID" class="input_field">';
			for($i=0;$i<$doctorNum;$i++)
			{	
				$doctor = $doctors[$i];
				$doctorID=$doctor[0];
				$doctorName=$doctor[1];
				if($doctorID==$selectedDoctorID)
				{
					$selected = "selected";
				}
				else
					$selected="";
				echo '<option value='.$doctor[0].' '.$selected.'>'.$doctor[1].'</option>';					
			}
			echo '</select>';
			echo '<div class="cleaner_h10"></div>';
			echo "<label for=\"date\">Date:</label><input id=\"datepicker\" name='date' value='".$date."' style='width: 150px; padding: 8px; background: #333028; border: 1px solid #886; color: #FFF;'/>";
			echo '<div class="cleaner_h10"></div>';
			echo '<input type="submit" class="submit_btn" name="checkAvailability" id="checkAvailability" value="Next" />';
			echo '<div class="cleaner_h10"></div>';
			?>
			</form>
			<form id="newAppoint" method="POST" action="newAppoint.php">
			<?php
				session_start();
				if(isset($_POST['checkAvailability']))//check if user pressed 'checkAvailability'
				{
					$selectedDoctorID=$_POST['doctorID'];
					$date=$_POST['date'];
					$_SESSION['selectedDoctorID']=$selectedDoctorID;
					$_SESSION['date']=$date;
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "mygovhospital";
					$con = new mysqli($servername, $username, $password, $dbname);
					$sql1 = "SELECT timeslot FROM appointment WHERE date='".$date."' and doctorID='".$selectedDoctorID."'";
					$result = mysqli_query($con, $sql1);
					$list = array();
					while($row = $result->fetch_assoc())
					{
						$list[] = $row;
					}
					$bookedTimeslots = array();
					foreach($list as $key=>$val)
					{
						foreach($val as $k=>$v)
						{ 
						// $v is string.
						// And $k is $val array index (0, 1, ....)
						$bookedTimeslots[] = $v;		
						}
					}
					$totalBookedTimeslots = count($bookedTimeslots);
					$sql2 = "SELECT sTime FROM timeslot";
					$result = mysqli_query($con, $sql2);
					$list = array();
					while($row = $result->fetch_assoc())
					{
						$list[] = $row;
					}
					$timeslots = array();
					foreach($list as $key=>$val)
					{
						foreach($val as $k=>$v)
						{ 
						// $v is string.
						// And $k is $val array index (0, 1, ....)
						$timeslots[] = $v;		
						}
					}
					$totalSlots = count($timeslots);
					echo '<label for="timeslot">Time:</label>';
					echo '<select name="timeslot" class="input_field">';
					for($i=0;$i<$totalSlots;$i++)
					{	
						$timeslot = $timeslots[$i];
						$disabled="";
						for($num=0;$num<$totalBookedTimeslots;$num++)
						{
							$bookedTimeslot=$bookedTimeslots[$num];
							if($timeslot==$bookedTimeslot)
							{
								$disabled = "disabled";
							}
						}
						echo '<option value='.$timeslot.' '.$disabled.'>'.$timeslot.'</option>';					
					}
					echo '</select>';
					echo '<div class="cleaner_h10"></div>';
					echo '<input type="submit" class="submit_btn" name="create" id="create" value="Create" />';
					echo '<input type="reset" class="submit_btn" name="reset" id="reset" value="Reset" />';
	
				}
			?>
			</form>
			</div>

        </div> <!-- end of content -->
		<div id="templatemo_footer">
			Copyright © 2017 <a href="patientUser.php">MYGovHospital</a> | <a href="#content" target="_parent">Patient | MY Gov Hospital</a> by <a href="patientUser.php" target="_parent">MY GOV Hospital</a>
        </div> <!-- end of footer -->
    </div> <!-- end of main -->
</div>
</body>
</html>