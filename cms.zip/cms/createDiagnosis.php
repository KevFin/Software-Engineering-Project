<?php
	session_start();
	$doctorID=$_SESSION['doctorID'];
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "mygovhospital";
	$con = new mysqli($servername, $username, $password, $dbname);
	if(isset($_POST['submit']))//check if user pressed 'check'
	{
		$selectedPatientID=$_SESSION['diagnosisPatientID'];
		$remark=$_SESSION['remark'];
		$numOfMed=$_SESSION['numofmed'];
		date_default_timezone_set('Asia/Kuala_Lumpur');
		$date=date('Y-m-d');
		$time=date('h:i:sa');
		$appointmentID="";
		$prescribedMedicines=array();
		$prescribedMedicine=array();
		for($i=0;$i<$numOfMed;$i++)
		{
			$medicineID=$_POST['medicineID'];
			$amount=$_POST['amount'];
			$prescribedMedicine[]= $medicineID[$i];
			$prescribedMedicine[]= $amount[$i];
			$prescribedMedicines[]=$prescribedMedicine;
			$prescribedMedicine=array();
		}
		$sql1 = "SELECT * FROM appointment WHERE patientID = '".$selectedPatientID."' and doctorID='".$doctorID."'";
		$result = mysqli_query($con, $sql1);
		$row = mysqli_fetch_assoc($result);
		if($row!=null)
			$appointmentID=$row['appointmentID'];
		$sql2 = "INSERT INTO diagnosis (date, time, remark, appointmentID, patientID, doctorID) 
															VALUES ('".$date."','".$time."','".$remark."','".$appointmentID."','".$selectedPatientID."','".$doctorID."')";
		
		$result = mysqli_query($con, $sql2);
		$diagnosisID = $con->insert_id;
		for($i=0;$i<$numOfMed;$i++)
		{
			$prescribedMedicine=$prescribedMedicines[$i];
			$medicineID=$prescribedMedicine[0];
			$amount=$prescribedMedicine[1];
			$sql3 = "SELECT * FROM medicine WHERE mID = '".$medicineID."'";
			$result = mysqli_query($con, $sql3);
			$row = mysqli_fetch_assoc($result);
			$unitPrice=$row['unitPrice'];
			$price=$unitPrice*$amount;
			$sql4 = "INSERT INTO prescribedmedicine (diagnosisID, medicineID, amount, price) 
															VALUES ('".$diagnosisID."','".$medicineID."','".$amount."','".$price."')";
			if (mysqli_query($con, $sql4))
			{
			}
			else
				echo "Error.";
			}
		header('location:doctorUser.php');
	}

?>