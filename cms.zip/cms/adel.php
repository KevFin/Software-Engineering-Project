 <?php
	$achievementID=trim($_GET["rno"]);
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "mygovhospital";
	$con = new mysqli($servername, $username, $password, $dbname);
	$sql1 = "UPDATE achievement SET ashow='N' WHERE aID=".$achievementID."";
	if (mysqli_query($con, $sql1))
	{
		header('location:Machv.php');						
	}
	else
	{
		echo "<script>alert('Error in deleting');</script>"; 
	}
?>